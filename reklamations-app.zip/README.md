# Reklamare – Reklamationsmanagement-System

Vollständige Web-App zum Erfassen, Bearbeiten, Verfolgen und Auswerten von
Kundenreklamationen im Team.

## Tech-Stack

- **Frontend:** React (Vite) + TypeScript + Tailwind CSS + Recharts
- **Backend:** Node.js + Express + TypeScript
- **Datenbank:** SQLite (über `better-sqlite3`, kein separater DB-Server nötig)

## Projektstruktur

```
reklamations-app/
├── backend/          Express-API (Port 4000)
│   ├── src/
│   │   ├── index.ts       Server-Einstiegspunkt
│   │   ├── lib/db.ts       DB-Schema + Demo-Daten
│   │   ├── lib/types.ts    Zod-Validierung
│   │   └── routes/         complaints.ts, users.ts
│   └── data/dev.db          (wird beim ersten Start automatisch erzeugt)
└── frontend/         React-App (Port 5173)
    └── src/
        ├── pages/            Dashboard, Liste, Detail, Neu-Formular
        ├── components/       Layout, Badges
        └── lib/              API-Client, Typen
```

## Lokal starten

**1. Backend starten** (Terminal 1):
```bash
cd backend
npm install
npx tsc
node dist/index.js
```
Läuft auf http://localhost:4000 – beim ersten Start werden automatisch
Demo-Daten (6 Beispiel-Reklamationen, 3 Team-Mitglieder) angelegt.

**2. Frontend starten** (Terminal 2):
```bash
cd frontend
npm install
npm run dev
```
Läuft auf http://localhost:5173 und leitet `/api`-Anfragen automatisch an
das Backend weiter (siehe `vite.config.ts`).

Im Browser dann einfach **http://localhost:5173** öffnen.

## Funktionen

- **Dashboard**: Kennzahlen (Gesamt, Offen, Überfällig, Ø Lösungszeit),
  Verteilung nach Priorität/Status, neueste Reklamationen
- **Reklamationsliste**: Volltextsuche, Filter nach Status/Priorität, Sortierung, Pagination
- **Neu erfassen**: Formular mit automatischer Referenznummern-Vergabe (z. B. `REK-2026-0007`)
- **Detailansicht**: Status/Priorität/Zuweisung ändern, Fälligkeitsdatum setzen,
  Lösungstext hinterlegen, Kommentarverlauf

## Datenmodell (Kurzüberblick)

**Complaint**: Referenznummer, Titel, Beschreibung, Kategorie, Status
(Neu / In Bearbeitung / Wartet auf Kunde / Eskaliert / Gelöst / Geschlossen),
Priorität (Niedrig / Mittel / Hoch / Kritisch), Kundendaten, Zuweisung,
Fälligkeit, Lösung.

**User**: Team-Mitglieder, denen Reklamationen zugewiesen werden können.

**Comment**: Verlaufseinträge zu einer Reklamation.

## Nächste sinnvolle Ausbaustufen

- Login/Authentifizierung für Team-Mitglieder
- E-Mail-Benachrichtigungen bei neuer Zuweisung oder überfälliger Reklamation
- Export (CSV/Excel) der Reklamationsliste
- Datei-Uploads (z. B. Fotos defekter Ware) je Reklamation
- Deployment: Backend z. B. auf Render/Fly.io, Frontend auf Vercel/Netlify,
  Datenbank auf einen persistenten Volume oder Wechsel auf Postgres
