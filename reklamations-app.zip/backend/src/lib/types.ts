import { z } from "zod";

export const STATUSES = [
  "NEU",
  "IN_BEARBEITUNG",
  "WARTET_AUF_KUNDE",
  "ESKALIERT",
  "GELOEST",
  "GESCHLOSSEN",
] as const;

export const PRIORITIES = ["NIEDRIG", "MITTEL", "HOCH", "KRITISCH"] as const;

export const complaintCreateSchema = z.object({
  title: z.string().min(3).max(200),
  description: z.string().min(3).max(5000),
  category: z.string().min(1).max(100),
  status: z.enum(STATUSES).optional(),
  priority: z.enum(PRIORITIES).optional(),
  customerName: z.string().min(1).max(200),
  customerEmail: z.string().email().optional().or(z.literal("")).optional(),
  customerPhone: z.string().max(50).optional(),
  orderNumber: z.string().max(100).optional(),
  assignedToId: z.string().optional().nullable(),
  dueDate: z.string().optional().nullable(),
});

export const complaintUpdateSchema = complaintCreateSchema.partial().extend({
  resolution: z.string().max(5000).optional().nullable(),
  resolvedAt: z.string().optional().nullable(),
});

export const commentCreateSchema = z.object({
  content: z.string().min(1).max(2000),
  authorId: z.string().optional().nullable(),
});
