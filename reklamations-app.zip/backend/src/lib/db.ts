import Database from "better-sqlite3";
import path from "path";
import fs from "fs";

const dbDir = path.join(__dirname, "..", "..", "data");
if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true });

const dbPath = path.join(dbDir, "dev.db");
export const db = new Database(dbPath);

db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

export function initDb() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      createdAt TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS complaints (
      id TEXT PRIMARY KEY,
      referenceNo TEXT NOT NULL UNIQUE,
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      category TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'NEU',
      priority TEXT NOT NULL DEFAULT 'MITTEL',
      customerName TEXT NOT NULL,
      customerEmail TEXT,
      customerPhone TEXT,
      orderNumber TEXT,
      assignedToId TEXT,
      resolution TEXT,
      dueDate TEXT,
      resolvedAt TEXT,
      createdAt TEXT NOT NULL DEFAULT (datetime('now')),
      updatedAt TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (assignedToId) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS comments (
      id TEXT PRIMARY KEY,
      content TEXT NOT NULL,
      createdAt TEXT NOT NULL DEFAULT (datetime('now')),
      complaintId TEXT NOT NULL,
      authorId TEXT,
      FOREIGN KEY (complaintId) REFERENCES complaints(id) ON DELETE CASCADE,
      FOREIGN KEY (authorId) REFERENCES users(id)
    );

    CREATE INDEX IF NOT EXISTS idx_complaints_status ON complaints(status);
    CREATE INDEX IF NOT EXISTS idx_complaints_priority ON complaints(priority);
    CREATE INDEX IF NOT EXISTS idx_complaints_createdAt ON complaints(createdAt);
  `);

  const userCount = (db.prepare("SELECT COUNT(*) as c FROM users").get() as { c: number }).c;
  if (userCount === 0) {
    seed();
  }
}

function seed() {
  const { randomUUID } = require("crypto");

  const users = [
    { id: randomUUID(), name: "Anna Berger", email: "anna.berger@firma.de" },
    { id: randomUUID(), name: "Tom Keller", email: "tom.keller@firma.de" },
    { id: randomUUID(), name: "Mira Solano", email: "mira.solano@firma.de" },
  ];
  const insertUser = db.prepare("INSERT INTO users (id, name, email) VALUES (?, ?, ?)");
  for (const u of users) insertUser.run(u.id, u.name, u.email);

  const complaints = [
    {
      referenceNo: "REK-2026-0001",
      title: "Falsche Ware geliefert",
      description: "Kunde hat Artikel A-1042 bestellt, erhalten wurde A-1039. Verpackung war unbeschädigt, Etikett stimmte nicht mit Inhalt überein.",
      category: "Lieferung",
      status: "IN_BEARBEITUNG",
      priority: "HOCH",
      customerName: "Julia Hoffmann",
      customerEmail: "j.hoffmann@example.com",
      customerPhone: "+49 151 2345678",
      orderNumber: "B-88213",
      assignedToId: users[0].id,
      dueDate: daysFromNow(2),
    },
    {
      referenceNo: "REK-2026-0002",
      title: "Produkt defekt bei Ankunft",
      description: "Gerät lässt sich nicht einschalten, Netzteil scheint defekt. Kunde bittet um Austausch oder Rückerstattung.",
      category: "Produktqualität",
      status: "NEU",
      priority: "KRITISCH",
      customerName: "Markus Weiss",
      customerEmail: "markus.weiss@example.com",
      customerPhone: "+49 170 9988776",
      orderNumber: "B-88450",
      assignedToId: null,
      dueDate: daysFromNow(1),
    },
    {
      referenceNo: "REK-2026-0003",
      title: "Rechnung enthält falschen Betrag",
      description: "Auf der Rechnung wurde ein Rabattcode nicht berücksichtigt. Differenz beträgt 14,90 EUR.",
      category: "Abrechnung",
      status: "WARTET_AUF_KUNDE",
      priority: "NIEDRIG",
      customerName: "Sabine Ott",
      customerEmail: "sabine.ott@example.com",
      customerPhone: null,
      orderNumber: "B-87990",
      assignedToId: users[1].id,
      dueDate: daysFromNow(5),
    },
    {
      referenceNo: "REK-2026-0004",
      title: "Lieferung stark verspätet",
      description: "Bestellung war für den 10.08. angekündigt, bisher keine Sendungsverfolgung aktualisiert. Kunde ist verärgert, droht mit Stornierung.",
      category: "Lieferung",
      status: "ESKALIERT",
      priority: "KRITISCH",
      customerName: "Deniz Aydın",
      customerEmail: "deniz.aydin@example.com",
      customerPhone: "+49 160 1122334",
      orderNumber: "B-88301",
      assignedToId: users[2].id,
      dueDate: daysFromNow(0),
    },
    {
      referenceNo: "REK-2026-0005",
      title: "Größe passt nicht laut Größentabelle",
      description: "Kunde hat nach Größentabelle bestellt, Kleidungsstück fällt deutlich kleiner aus. Möchte kostenlosen Umtausch.",
      category: "Produktqualität",
      status: "GELOEST",
      priority: "MITTEL",
      customerName: "Laura Fischer",
      customerEmail: "laura.fischer@example.com",
      customerPhone: null,
      orderNumber: "B-87650",
      assignedToId: users[0].id,
      dueDate: daysFromNow(-3),
      resolution: "Kostenloser Umtausch gegen eine Größe größer versendet. Kunde hat Erhalt bestätigt.",
      resolvedAt: daysFromNow(-2),
    },
    {
      referenceNo: "REK-2026-0006",
      title: "Doppelte Abbuchung",
      description: "Betrag wurde zweimal vom Konto abgebucht. Kunde bittet um Rückerstattung der doppelten Zahlung.",
      category: "Abrechnung",
      status: "GESCHLOSSEN",
      priority: "HOCH",
      customerName: "Peter Grün",
      customerEmail: "peter.gruen@example.com",
      customerPhone: "+49 175 5566778",
      orderNumber: "B-87500",
      assignedToId: users[1].id,
      dueDate: daysFromNow(-10),
      resolution: "Doppelte Abbuchung bestätigt und binnen 3 Werktagen zurückerstattet.",
      resolvedAt: daysFromNow(-9),
    },
  ];

  const insertComplaint = db.prepare(`
    INSERT INTO complaints
      (id, referenceNo, title, description, category, status, priority,
       customerName, customerEmail, customerPhone, orderNumber, assignedToId,
       resolution, dueDate, resolvedAt, createdAt)
    VALUES (@id, @referenceNo, @title, @description, @category, @status, @priority,
       @customerName, @customerEmail, @customerPhone, @orderNumber, @assignedToId,
       @resolution, @dueDate, @resolvedAt, @createdAt)
  `);

  // Stagger creation dates so older/resolved tickets look plausible
  const createdOffsets = [-6, -1, -8, -4, -12, -20];

  complaints.forEach((c, i) => {
    insertComplaint.run({
      id: randomUUID(),
      referenceNo: c.referenceNo,
      title: c.title,
      description: c.description,
      category: c.category,
      status: c.status,
      priority: c.priority,
      customerName: c.customerName,
      customerEmail: c.customerEmail,
      customerPhone: c.customerPhone ?? null,
      orderNumber: c.orderNumber,
      assignedToId: c.assignedToId,
      resolution: (c as any).resolution ?? null,
      dueDate: c.dueDate,
      resolvedAt: (c as any).resolvedAt ?? null,
      createdAt: daysFromNow(createdOffsets[i] ?? -1),
    });
  });
}

function daysFromNow(days: number): string {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return d.toISOString();
}
