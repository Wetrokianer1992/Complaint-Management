import { Router } from "express";
import { randomUUID } from "crypto";
import { db } from "../lib/db";

const router = Router();

router.get("/", (req, res) => {
  const rows = db.prepare(`SELECT id, name, email, createdAt FROM users ORDER BY name ASC`).all();
  res.json(rows);
});

router.post("/", (req, res) => {
  const { name, email } = req.body;
  if (!name || !email) {
    return res.status(400).json({ error: "Name und E-Mail sind erforderlich" });
  }
  const id = randomUUID();
  try {
    db.prepare(`INSERT INTO users (id, name, email) VALUES (?, ?, ?)`).run(id, name, email);
  } catch (e: any) {
    if (String(e.message).includes("UNIQUE")) {
      return res.status(409).json({ error: "E-Mail bereits vergeben" });
    }
    throw e;
  }
  const created = db.prepare(`SELECT * FROM users WHERE id = ?`).get(id);
  res.status(201).json(created);
});

export default router;
