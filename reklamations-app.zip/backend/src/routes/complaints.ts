import { Router } from "express";
import { randomUUID } from "crypto";
import { db } from "../lib/db";
import { complaintCreateSchema, complaintUpdateSchema } from "../lib/types";

const router = Router();

function nextReferenceNo(): string {
  const year = new Date().getFullYear();
  const row = db
    .prepare(
      `SELECT referenceNo FROM complaints WHERE referenceNo LIKE ? ORDER BY referenceNo DESC LIMIT 1`
    )
    .get(`REK-${year}-%`) as { referenceNo: string } | undefined;

  let next = 1;
  if (row) {
    const parts = row.referenceNo.split("-");
    next = parseInt(parts[2], 10) + 1;
  }
  return `REK-${year}-${String(next).padStart(4, "0")}`;
}

// GET /api/complaints - list with filters, search, pagination
router.get("/", (req, res) => {
  const { status, priority, category, assignedToId, search, sort = "createdAt_desc", page = "1", pageSize = "20" } = req.query as Record<string, string>;

  const where: string[] = [];
  const params: any[] = [];

  if (status) {
    where.push(`c.status = ?`);
    params.push(status);
  }
  if (priority) {
    where.push(`c.priority = ?`);
    params.push(priority);
  }
  if (category) {
    where.push(`c.category = ?`);
    params.push(category);
  }
  if (assignedToId) {
    where.push(`c.assignedToId = ?`);
    params.push(assignedToId);
  }
  if (search) {
    where.push(`(c.title LIKE ? OR c.description LIKE ? OR c.customerName LIKE ? OR c.referenceNo LIKE ? OR c.orderNumber LIKE ?)`);
    const like = `%${search}%`;
    params.push(like, like, like, like, like);
  }

  const whereClause = where.length ? `WHERE ${where.join(" AND ")}` : "";

  const [sortField, sortDir] = sort.split("_");
  const allowedSortFields = ["createdAt", "updatedAt", "dueDate", "priority", "status"];
  const sf = allowedSortFields.includes(sortField) ? sortField : "createdAt";
  const sd = sortDir === "asc" ? "ASC" : "DESC";

  const pageNum = Math.max(1, parseInt(page, 10) || 1);
  const size = Math.min(100, Math.max(1, parseInt(pageSize, 10) || 20));
  const offset = (pageNum - 1) * size;

  const totalRow = db.prepare(`SELECT COUNT(*) as c FROM complaints c ${whereClause}`).get(...params) as { c: number };

  const rows = db
    .prepare(
      `SELECT c.*, u.name as assignedToName
       FROM complaints c
       LEFT JOIN users u ON u.id = c.assignedToId
       ${whereClause}
       ORDER BY c.${sf} ${sd}
       LIMIT ? OFFSET ?`
    )
    .all(...params, size, offset);

  res.json({
    data: rows,
    pagination: {
      page: pageNum,
      pageSize: size,
      total: totalRow.c,
      totalPages: Math.ceil(totalRow.c / size),
    },
  });
});

// GET /api/complaints/stats - dashboard aggregates
router.get("/stats", (req, res) => {
  const byStatus = db.prepare(`SELECT status, COUNT(*) as count FROM complaints GROUP BY status`).all();
  const byPriority = db.prepare(`SELECT priority, COUNT(*) as count FROM complaints GROUP BY priority`).all();
  const byCategory = db.prepare(`SELECT category, COUNT(*) as count FROM complaints GROUP BY category ORDER BY count DESC`).all();

  const total = (db.prepare(`SELECT COUNT(*) as c FROM complaints`).get() as { c: number }).c;
  const open = (
    db
      .prepare(`SELECT COUNT(*) as c FROM complaints WHERE status NOT IN ('GELOEST', 'GESCHLOSSEN')`)
      .get() as { c: number }
  ).c;
  const overdue = (
    db
      .prepare(
        `SELECT COUNT(*) as c FROM complaints WHERE dueDate IS NOT NULL AND dueDate < datetime('now') AND status NOT IN ('GELOEST', 'GESCHLOSSEN')`
      )
      .get() as { c: number }
  ).c;

  const avgResolutionRow = db
    .prepare(
      `SELECT AVG(julianday(resolvedAt) - julianday(createdAt)) as avgDays
       FROM complaints WHERE resolvedAt IS NOT NULL`
    )
    .get() as { avgDays: number | null };

  const last30Days = db
    .prepare(
      `SELECT date(createdAt) as day, COUNT(*) as count
       FROM complaints
       WHERE createdAt >= datetime('now', '-30 days')
       GROUP BY date(createdAt)
       ORDER BY day ASC`
    )
    .all();

  res.json({
    total,
    open,
    overdue,
    avgResolutionDays: avgResolutionRow.avgDays ? Math.round(avgResolutionRow.avgDays * 10) / 10 : null,
    byStatus,
    byPriority,
    byCategory,
    last30Days,
  });
});

// GET /api/complaints/:id
router.get("/:id", (req, res) => {
  const row = db
    .prepare(
      `SELECT c.*, u.name as assignedToName FROM complaints c LEFT JOIN users u ON u.id = c.assignedToId WHERE c.id = ?`
    )
    .get(req.params.id);

  if (!row) return res.status(404).json({ error: "Reklamation nicht gefunden" });

  const comments = db
    .prepare(
      `SELECT cm.*, u.name as authorName FROM comments cm LEFT JOIN users u ON u.id = cm.authorId WHERE cm.complaintId = ? ORDER BY cm.createdAt ASC`
    )
    .all(req.params.id);

  res.json({ ...row, comments });
});

// POST /api/complaints
router.post("/", (req, res) => {
  const parsed = complaintCreateSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: "Ungültige Eingabe", details: parsed.error.flatten() });
  }
  const data = parsed.data;
  const id = randomUUID();
  const referenceNo = nextReferenceNo();

  db.prepare(
    `INSERT INTO complaints
      (id, referenceNo, title, description, category, status, priority,
       customerName, customerEmail, customerPhone, orderNumber, assignedToId, dueDate)
     VALUES (@id, @referenceNo, @title, @description, @category, @status, @priority,
       @customerName, @customerEmail, @customerPhone, @orderNumber, @assignedToId, @dueDate)`
  ).run({
    id,
    referenceNo,
    title: data.title,
    description: data.description,
    category: data.category,
    status: data.status ?? "NEU",
    priority: data.priority ?? "MITTEL",
    customerName: data.customerName,
    customerEmail: data.customerEmail || null,
    customerPhone: data.customerPhone || null,
    orderNumber: data.orderNumber || null,
    assignedToId: data.assignedToId || null,
    dueDate: data.dueDate || null,
  });

  const created = db.prepare(`SELECT * FROM complaints WHERE id = ?`).get(id);
  res.status(201).json(created);
});

// PATCH /api/complaints/:id
router.patch("/:id", (req, res) => {
  const existing = db.prepare(`SELECT * FROM complaints WHERE id = ?`).get(req.params.id);
  if (!existing) return res.status(404).json({ error: "Reklamation nicht gefunden" });

  const parsed = complaintUpdateSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: "Ungültige Eingabe", details: parsed.error.flatten() });
  }
  const data = parsed.data;

  const fields: string[] = [];
  const params: any = { id: req.params.id };

  const assignable: (keyof typeof data)[] = [
    "title",
    "description",
    "category",
    "status",
    "priority",
    "customerName",
    "customerEmail",
    "customerPhone",
    "orderNumber",
    "assignedToId",
    "resolution",
    "dueDate",
  ];

  for (const key of assignable) {
    if (data[key] !== undefined) {
      fields.push(`${key} = @${key}`);
      params[key] = data[key] === "" ? null : data[key];
    }
  }

  // Auto-set resolvedAt when moving into a resolved state
  if (data.status === "GELOEST" || data.status === "GESCHLOSSEN") {
    fields.push(`resolvedAt = COALESCE(resolvedAt, datetime('now'))`);
  }
  if (data.status && data.status !== "GELOEST" && data.status !== "GESCHLOSSEN") {
    fields.push(`resolvedAt = NULL`);
  }

  if (fields.length === 0) {
    return res.status(400).json({ error: "Keine Änderungen übermittelt" });
  }

  fields.push(`updatedAt = datetime('now')`);

  db.prepare(`UPDATE complaints SET ${fields.join(", ")} WHERE id = @id`).run(params);

  const updated = db.prepare(`SELECT * FROM complaints WHERE id = ?`).get(req.params.id);
  res.json(updated);
});

// DELETE /api/complaints/:id
router.delete("/:id", (req, res) => {
  const existing = db.prepare(`SELECT * FROM complaints WHERE id = ?`).get(req.params.id);
  if (!existing) return res.status(404).json({ error: "Reklamation nicht gefunden" });

  db.prepare(`DELETE FROM complaints WHERE id = ?`).run(req.params.id);
  res.status(204).send();
});

// POST /api/complaints/:id/comments
router.post("/:id/comments", (req, res) => {
  const existing = db.prepare(`SELECT * FROM complaints WHERE id = ?`).get(req.params.id);
  if (!existing) return res.status(404).json({ error: "Reklamation nicht gefunden" });

  const { content, authorId } = req.body;
  if (!content || typeof content !== "string" || content.trim().length === 0) {
    return res.status(400).json({ error: "Kommentartext fehlt" });
  }

  const id = randomUUID();
  db.prepare(`INSERT INTO comments (id, content, complaintId, authorId) VALUES (?, ?, ?, ?)`).run(
    id,
    content.trim(),
    req.params.id,
    authorId || null
  );

  const created = db
    .prepare(`SELECT cm.*, u.name as authorName FROM comments cm LEFT JOIN users u ON u.id = cm.authorId WHERE cm.id = ?`)
    .get(id);

  res.status(201).json(created);
});

export default router;
