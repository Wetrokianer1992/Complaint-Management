import { BrowserRouter, Routes, Route } from "react-router-dom";
import Layout from "./components/Layout";
import Dashboard from "./pages/Dashboard";
import ComplaintsList from "./pages/ComplaintsList";
import ComplaintDetail from "./pages/ComplaintDetail";
import ComplaintNew from "./pages/ComplaintNew";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<Layout />}>
          <Route path="/" element={<Dashboard />} />
          <Route path="/complaints" element={<ComplaintsList />} />
          <Route path="/complaints/new" element={<ComplaintNew />} />
          <Route path="/complaints/:id" element={<ComplaintDetail />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
