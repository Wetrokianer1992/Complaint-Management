import { NavLink, Outlet } from "react-router-dom";

const navItems = [
  { to: "/", label: "Übersicht", end: true },
  { to: "/complaints", label: "Reklamationen" },
  { to: "/complaints/new", label: "Neu erfassen" },
];

export default function Layout() {
  return (
    <div className="flex h-screen w-full overflow-hidden">
      <aside
        className="flex w-64 shrink-0 flex-col justify-between px-5 py-6"
        style={{ backgroundColor: "var(--color-navy)" }}
      >
        <div>
          <div className="mb-8 flex items-center gap-2 px-1">
            <div className="flex h-8 w-8 items-center justify-center rounded-md" style={{ backgroundColor: "var(--color-teal)" }}>
              <span className="font-display text-sm font-semibold text-white">R</span>
            </div>
            <div>
              <p className="font-display text-base font-semibold leading-tight text-white">Reklamare</p>
              <p className="text-[11px] uppercase tracking-wide text-white/40">Reklamationsmanagement</p>
            </div>
          </div>

          <nav className="flex flex-col gap-1">
            {navItems.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.end}
                className={({ isActive }) =>
                  `rounded-md px-3 py-2 text-sm font-medium transition-colors ${
                    isActive
                      ? "bg-white/10 text-white"
                      : "text-white/60 hover:bg-white/5 hover:text-white/90"
                  }`
                }
              >
                {item.label}
              </NavLink>
            ))}
          </nav>
        </div>

        <div className="rounded-md bg-white/5 px-3 py-3">
          <p className="text-xs text-white/50">Team</p>
          <p className="text-sm font-medium text-white">Kundenservice</p>
        </div>
      </aside>

      <main className="flex-1 overflow-y-auto">
        <div className="mx-auto max-w-6xl px-8 py-8">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
