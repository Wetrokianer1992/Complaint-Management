import type { Priority, Status } from "../lib/types";
import { PRIORITY_LABELS, STATUS_LABELS } from "../lib/types";

export const PRIORITY_COLOR: Record<Priority, string> = {
  KRITISCH: "var(--color-crit)",
  HOCH: "var(--color-high)",
  MITTEL: "var(--color-med)",
  NIEDRIG: "var(--color-low)",
};

const STATUS_STYLE: Record<Status, string> = {
  NEU: "bg-blue-50 text-blue-700 ring-blue-200",
  IN_BEARBEITUNG: "bg-amber-50 text-amber-700 ring-amber-200",
  WARTET_AUF_KUNDE: "bg-purple-50 text-purple-700 ring-purple-200",
  ESKALIERT: "bg-red-50 text-red-700 ring-red-200",
  GELOEST: "bg-emerald-50 text-emerald-700 ring-emerald-200",
  GESCHLOSSEN: "bg-stone-100 text-stone-600 ring-stone-200",
};

export function StatusBadge({ status }: { status: Status }) {
  return (
    <span
      className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium ring-1 ring-inset ${STATUS_STYLE[status]}`}
    >
      {STATUS_LABELS[status]}
    </span>
  );
}

export function PriorityBadge({ priority }: { priority: Priority }) {
  return (
    <span
      className="inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium ring-1 ring-inset ring-stone-200 bg-white"
    >
      <span
        className="h-1.5 w-1.5 rounded-full"
        style={{ backgroundColor: PRIORITY_COLOR[priority] }}
      />
      {PRIORITY_LABELS[priority]}
    </span>
  );
}

export function PriorityRail({ priority }: { priority: Priority }) {
  return (
    <span
      className="absolute left-0 top-0 h-full w-1 rounded-l-lg"
      style={{ backgroundColor: PRIORITY_COLOR[priority] }}
      aria-hidden
    />
  );
}
