import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../lib/api";
import type { Complaint, Stats } from "../lib/types";
import { PRIORITY_LABELS, STATUS_LABELS } from "../lib/types";
import { PRIORITY_COLOR, PriorityBadge, StatusBadge } from "../components/Badges";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  ResponsiveContainer,
  Tooltip,
  CartesianGrid,
  PieChart,
  Pie,
  Cell,
} from "recharts";

const STATUS_COLORS: Record<string, string> = {
  NEU: "#2563eb",
  IN_BEARBEITUNG: "#d97706",
  WARTET_AUF_KUNDE: "#7c3aed",
  ESKALIERT: "#dc2626",
  GELOEST: "#059669",
  GESCHLOSSEN: "#78716c",
};

export default function Dashboard() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [recent, setRecent] = useState<Complaint[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    Promise.all([api.getStats(), api.listComplaints({ sort: "createdAt_desc", pageSize: 5 })])
      .then(([s, c]) => {
        setStats(s);
        setRecent(c.data);
      })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <p className="text-sm text-stone-500">Lädt…</p>;
  if (error) return <p className="text-sm text-red-600">{error}</p>;
  if (!stats) return null;

  const priorityData = (["KRITISCH", "HOCH", "MITTEL", "NIEDRIG"] as const).map((p) => ({
    name: PRIORITY_LABELS[p],
    value: stats.byPriority.find((x) => x.priority === p)?.count ?? 0,
    color: PRIORITY_COLOR[p],
  }));

  const statusData = Object.entries(STATUS_LABELS).map(([key, label]) => ({
    name: label,
    value: stats.byStatus.find((x) => x.status === key)?.count ?? 0,
    color: STATUS_COLORS[key],
  }));

  return (
    <div className="space-y-8">
      <header>
        <p className="font-display text-2xl font-semibold text-stone-900">Übersicht</p>
        <p className="mt-1 text-sm text-stone-500">Aktueller Stand aller Kundenreklamationen.</p>
      </header>

      <div className="grid grid-cols-4 gap-4">
        <StatCard label="Gesamt" value={stats.total} />
        <StatCard label="Offen" value={stats.open} accent="var(--color-teal)" />
        <StatCard label="Überfällig" value={stats.overdue} accent="var(--color-crit)" />
        <StatCard
          label="Ø Lösungszeit"
          value={stats.avgResolutionDays !== null ? `${stats.avgResolutionDays} Tage` : "–"}
        />
      </div>

      <div className="grid grid-cols-2 gap-6">
        <div className="rounded-xl border border-stone-200 bg-white p-5">
          <p className="mb-4 text-sm font-medium text-stone-700">Nach Priorität</p>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={priorityData} layout="vertical" margin={{ left: 8 }}>
              <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#eee" />
              <XAxis type="number" allowDecimals={false} tick={{ fontSize: 12 }} />
              <YAxis type="category" dataKey="name" width={90} tick={{ fontSize: 12 }} />
              <Tooltip />
              <Bar dataKey="value" radius={[0, 4, 4, 0]}>
                {priorityData.map((entry, i) => (
                  <Cell key={i} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="rounded-xl border border-stone-200 bg-white p-5">
          <p className="mb-4 text-sm font-medium text-stone-700">Nach Status</p>
          <div className="flex items-center gap-6">
            <ResponsiveContainer width="55%" height={200}>
              <PieChart>
                <Pie data={statusData} dataKey="value" nameKey="name" innerRadius={45} outerRadius={80} paddingAngle={2}>
                  {statusData.map((entry, i) => (
                    <Cell key={i} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <ul className="space-y-1.5 text-xs text-stone-600">
              {statusData.map((s) => (
                <li key={s.name} className="flex items-center gap-2">
                  <span className="h-2 w-2 rounded-full" style={{ backgroundColor: s.color }} />
                  {s.name} <span className="text-stone-400">({s.value})</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      <div className="rounded-xl border border-stone-200 bg-white">
        <div className="flex items-center justify-between border-b border-stone-100 px-5 py-4">
          <p className="text-sm font-medium text-stone-700">Neueste Reklamationen</p>
          <Link to="/complaints" className="text-xs font-medium" style={{ color: "var(--color-teal)" }}>
            Alle ansehen →
          </Link>
        </div>
        <ul className="divide-y divide-stone-100">
          {recent.map((c) => (
            <li key={c.id}>
              <Link
                to={`/complaints/${c.id}`}
                className="flex items-center justify-between gap-4 px-5 py-3 hover:bg-stone-50"
              >
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs text-stone-400">{c.referenceNo}</span>
                    <span className="truncate text-sm font-medium text-stone-800">{c.title}</span>
                  </div>
                  <p className="mt-0.5 text-xs text-stone-500">{c.customerName}</p>
                </div>
                <div className="flex shrink-0 items-center gap-2">
                  <PriorityBadge priority={c.priority} />
                  <StatusBadge status={c.status} />
                </div>
              </Link>
            </li>
          ))}
          {recent.length === 0 && (
            <li className="px-5 py-6 text-sm text-stone-400">Noch keine Reklamationen erfasst.</li>
          )}
        </ul>
      </div>
    </div>
  );
}

function StatCard({ label, value, accent }: { label: string; value: string | number; accent?: string }) {
  return (
    <div className="rounded-xl border border-stone-200 bg-white p-5">
      <p className="text-xs font-medium uppercase tracking-wide text-stone-400">{label}</p>
      <p className="mt-2 font-display text-3xl font-semibold" style={{ color: accent ?? "var(--color-ink)" }}>
        {value}
      </p>
    </div>
  );
}
