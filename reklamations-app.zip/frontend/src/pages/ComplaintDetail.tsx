import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { api } from "../lib/api";
import type { Complaint, User } from "../lib/types";
import { PRIORITIES, PRIORITY_LABELS, STATUSES, STATUS_LABELS } from "../lib/types";
import { PriorityBadge, StatusBadge } from "../components/Badges";

export default function ComplaintDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [complaint, setComplaint] = useState<Complaint | null>(null);
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [comment, setComment] = useState("");
  const [resolution, setResolution] = useState("");

  function load() {
    if (!id) return;
    setLoading(true);
    Promise.all([api.getComplaint(id), api.listUsers()])
      .then(([c, u]) => {
        setComplaint(c);
        setResolution(c.resolution ?? "");
        setUsers(u);
      })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }

  useEffect(load, [id]);

  async function update(patch: Partial<Complaint>) {
    if (!id) return;
    setSaving(true);
    try {
      const updated = await api.updateComplaint(id, patch);
      setComplaint(updated);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setSaving(false);
    }
  }

  async function submitComment() {
    if (!id || !comment.trim()) return;
    try {
      await api.addComment(id, comment.trim());
      setComment("");
      load();
    } catch (e: any) {
      setError(e.message);
    }
  }

  async function handleDelete() {
    if (!id) return;
    if (!confirm("Diese Reklamation wirklich löschen?")) return;
    await api.deleteComplaint(id);
    navigate("/complaints");
  }

  if (loading) return <p className="text-sm text-stone-500">Lädt…</p>;
  if (error && !complaint) return <p className="text-sm text-red-600">{error}</p>;
  if (!complaint) return null;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <Link to="/complaints" className="text-sm text-stone-500 hover:text-stone-700">
          ← Zurück zur Übersicht
        </Link>
        <button onClick={handleDelete} className="text-sm text-red-500 hover:text-red-700">
          Löschen
        </button>
      </div>

      <header className="flex items-start justify-between gap-6">
        <div>
          <span className="font-mono text-xs text-stone-400">{complaint.referenceNo}</span>
          <h1 className="font-display text-2xl font-semibold text-stone-900">{complaint.title}</h1>
          <p className="mt-1 text-sm text-stone-500">
            {complaint.customerName}
            {complaint.customerEmail ? ` · ${complaint.customerEmail}` : ""}
            {complaint.customerPhone ? ` · ${complaint.customerPhone}` : ""}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <PriorityBadge priority={complaint.priority} />
          <StatusBadge status={complaint.status} />
        </div>
      </header>

      <div className="grid grid-cols-3 gap-6">
        <div className="col-span-2 space-y-6">
          <section className="rounded-xl border border-stone-200 bg-white p-5">
            <p className="mb-2 text-sm font-medium text-stone-700">Beschreibung</p>
            <p className="whitespace-pre-wrap text-sm text-stone-600">{complaint.description}</p>
          </section>

          <section className="rounded-xl border border-stone-200 bg-white p-5">
            <p className="mb-2 text-sm font-medium text-stone-700">Lösung / Ergebnis</p>
            <textarea
              value={resolution}
              onChange={(e) => setResolution(e.target.value)}
              rows={3}
              placeholder="Wie wurde die Reklamation gelöst?"
              className="w-full rounded-md border border-stone-200 p-3 text-sm outline-none focus:border-stone-400"
            />
            <button
              disabled={saving}
              onClick={() => update({ resolution })}
              className="mt-2 rounded-md px-4 py-1.5 text-sm font-medium text-white disabled:opacity-50"
              style={{ backgroundColor: "var(--color-teal)" }}
            >
              Speichern
            </button>
          </section>

          <section className="rounded-xl border border-stone-200 bg-white p-5">
            <p className="mb-3 text-sm font-medium text-stone-700">Verlauf / Kommentare</p>
            <ul className="space-y-3">
              {complaint.comments?.map((c) => (
                <li key={c.id} className="rounded-md bg-stone-50 p-3 text-sm">
                  <p className="text-stone-700">{c.content}</p>
                  <p className="mt-1 text-xs text-stone-400">
                    {c.authorName ?? "System"} · {new Date(c.createdAt).toLocaleString("de-DE")}
                  </p>
                </li>
              ))}
              {(!complaint.comments || complaint.comments.length === 0) && (
                <p className="text-xs text-stone-400">Noch keine Kommentare.</p>
              )}
            </ul>
            <div className="mt-4 flex gap-2">
              <input
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && submitComment()}
                placeholder="Kommentar hinzufügen…"
                className="flex-1 rounded-md border border-stone-200 px-3 py-2 text-sm outline-none focus:border-stone-400"
              />
              <button
                onClick={submitComment}
                className="rounded-md border border-stone-200 px-4 py-2 text-sm font-medium text-stone-700 hover:bg-stone-50"
              >
                Senden
              </button>
            </div>
          </section>
        </div>

        <div className="space-y-4">
          <section className="rounded-xl border border-stone-200 bg-white p-5">
            <p className="mb-3 text-sm font-medium text-stone-700">Bearbeitung</p>

            <Field label="Status">
              <select
                value={complaint.status}
                onChange={(e) => update({ status: e.target.value as any })}
                className="w-full rounded-md border border-stone-200 px-2 py-1.5 text-sm"
              >
                {STATUSES.map((s) => (
                  <option key={s} value={s}>
                    {STATUS_LABELS[s]}
                  </option>
                ))}
              </select>
            </Field>

            <Field label="Priorität">
              <select
                value={complaint.priority}
                onChange={(e) => update({ priority: e.target.value as any })}
                className="w-full rounded-md border border-stone-200 px-2 py-1.5 text-sm"
              >
                {PRIORITIES.map((p) => (
                  <option key={p} value={p}>
                    {PRIORITY_LABELS[p]}
                  </option>
                ))}
              </select>
            </Field>

            <Field label="Zugewiesen an">
              <select
                value={complaint.assignedToId ?? ""}
                onChange={(e) => update({ assignedToId: e.target.value || null })}
                className="w-full rounded-md border border-stone-200 px-2 py-1.5 text-sm"
              >
                <option value="">Nicht zugewiesen</option>
                {users.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.name}
                  </option>
                ))}
              </select>
            </Field>

            <Field label="Fälligkeit">
              <input
                type="date"
                value={complaint.dueDate ? complaint.dueDate.slice(0, 10) : ""}
                onChange={(e) => update({ dueDate: e.target.value ? new Date(e.target.value).toISOString() : null })}
                className="w-full rounded-md border border-stone-200 px-2 py-1.5 text-sm"
              />
            </Field>
          </section>

          <section className="rounded-xl border border-stone-200 bg-white p-5 text-xs text-stone-500">
            <p className="mb-1">
              <span className="font-medium text-stone-600">Kategorie:</span> {complaint.category}
            </p>
            {complaint.orderNumber && (
              <p className="mb-1">
                <span className="font-medium text-stone-600">Bestellnr.:</span> {complaint.orderNumber}
              </p>
            )}
            <p className="mb-1">
              <span className="font-medium text-stone-600">Erstellt:</span>{" "}
              {new Date(complaint.createdAt).toLocaleString("de-DE")}
            </p>
            <p>
              <span className="font-medium text-stone-600">Aktualisiert:</span>{" "}
              {new Date(complaint.updatedAt).toLocaleString("de-DE")}
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="mb-3">
      <label className="mb-1 block text-xs font-medium text-stone-500">{label}</label>
      {children}
    </div>
  );
}
