import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../lib/api";
import type { Complaint } from "../lib/types";
import { PRIORITIES, PRIORITY_LABELS, STATUSES, STATUS_LABELS } from "../lib/types";
import { PriorityBadge, PriorityRail, StatusBadge } from "../components/Badges";

export default function ComplaintsList() {
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("");
  const [priority, setPriority] = useState("");
  const [sort, setSort] = useState("createdAt_desc");
  const [page, setPage] = useState(1);
  const pageSize = 15;

  useEffect(() => {
    setLoading(true);
    const t = setTimeout(() => {
      api
        .listComplaints({ search, status, priority, sort, page, pageSize })
        .then((res) => {
          setComplaints(res.data);
          setTotal(res.pagination.total);
        })
        .catch((e) => setError(e.message))
        .finally(() => setLoading(false));
    }, 250);
    return () => clearTimeout(t);
  }, [search, status, priority, sort, page]);

  const totalPages = Math.max(1, Math.ceil(total / pageSize));

  return (
    <div className="space-y-6">
      <header className="flex items-center justify-between">
        <div>
          <p className="font-display text-2xl font-semibold text-stone-900">Reklamationen</p>
          <p className="mt-1 text-sm text-stone-500">{total} Einträge gesamt</p>
        </div>
        <Link
          to="/complaints/new"
          className="rounded-md px-4 py-2 text-sm font-medium text-white"
          style={{ backgroundColor: "var(--color-teal)" }}
        >
          + Neue Reklamation
        </Link>
      </header>

      <div className="flex flex-wrap items-center gap-3 rounded-xl border border-stone-200 bg-white p-3">
        <input
          value={search}
          onChange={(e) => {
            setPage(1);
            setSearch(e.target.value);
          }}
          placeholder="Suche nach Titel, Kunde, Referenz…"
          className="min-w-[220px] flex-1 rounded-md border border-stone-200 px-3 py-2 text-sm outline-none focus:border-stone-400"
        />
        <select
          value={status}
          onChange={(e) => {
            setPage(1);
            setStatus(e.target.value);
          }}
          className="rounded-md border border-stone-200 px-3 py-2 text-sm outline-none focus:border-stone-400"
        >
          <option value="">Alle Status</option>
          {STATUSES.map((s) => (
            <option key={s} value={s}>
              {STATUS_LABELS[s]}
            </option>
          ))}
        </select>
        <select
          value={priority}
          onChange={(e) => {
            setPage(1);
            setPriority(e.target.value);
          }}
          className="rounded-md border border-stone-200 px-3 py-2 text-sm outline-none focus:border-stone-400"
        >
          <option value="">Alle Prioritäten</option>
          {PRIORITIES.map((p) => (
            <option key={p} value={p}>
              {PRIORITY_LABELS[p]}
            </option>
          ))}
        </select>
        <select
          value={sort}
          onChange={(e) => setSort(e.target.value)}
          className="rounded-md border border-stone-200 px-3 py-2 text-sm outline-none focus:border-stone-400"
        >
          <option value="createdAt_desc">Neueste zuerst</option>
          <option value="createdAt_asc">Älteste zuerst</option>
          <option value="dueDate_asc">Fälligkeit aufsteigend</option>
          <option value="priority_desc">Priorität</option>
        </select>
      </div>

      {error && <p className="text-sm text-red-600">{error}</p>}

      <div className="space-y-2">
        {complaints.map((c) => (
          <Link
            to={`/complaints/${c.id}`}
            key={c.id}
            className="relative block overflow-hidden rounded-lg border border-stone-200 bg-white py-3 pl-5 pr-4 transition-shadow hover:shadow-sm"
          >
            <PriorityRail priority={c.priority} />
            <div className="flex items-center justify-between gap-4">
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs text-stone-400">{c.referenceNo}</span>
                  <span className="truncate text-sm font-medium text-stone-800">{c.title}</span>
                </div>
                <p className="mt-1 text-xs text-stone-500">
                  {c.customerName} · {c.category}
                  {c.assignedToName ? ` · zugewiesen an ${c.assignedToName}` : " · nicht zugewiesen"}
                </p>
              </div>
              <div className="flex shrink-0 items-center gap-2">
                {c.dueDate && (
                  <span className="text-xs text-stone-400">
                    Fällig {new Date(c.dueDate).toLocaleDateString("de-DE")}
                  </span>
                )}
                <PriorityBadge priority={c.priority} />
                <StatusBadge status={c.status} />
              </div>
            </div>
          </Link>
        ))}

        {!loading && complaints.length === 0 && (
          <div className="rounded-lg border border-dashed border-stone-300 p-8 text-center text-sm text-stone-400">
            Keine Reklamationen gefunden.
          </div>
        )}
      </div>

      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-2 pt-2">
          <button
            disabled={page <= 1}
            onClick={() => setPage((p) => p - 1)}
            className="rounded-md border border-stone-200 px-3 py-1.5 text-sm disabled:opacity-40"
          >
            Zurück
          </button>
          <span className="text-sm text-stone-500">
            Seite {page} / {totalPages}
          </span>
          <button
            disabled={page >= totalPages}
            onClick={() => setPage((p) => p + 1)}
            className="rounded-md border border-stone-200 px-3 py-1.5 text-sm disabled:opacity-40"
          >
            Weiter
          </button>
        </div>
      )}
    </div>
  );
}
