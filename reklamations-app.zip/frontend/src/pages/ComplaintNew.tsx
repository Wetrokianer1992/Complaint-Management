import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../lib/api";
import { PRIORITIES, PRIORITY_LABELS } from "../lib/types";

const CATEGORIES = ["Lieferung", "Produktqualität", "Abrechnung", "Kundenservice", "Sonstiges"];

export default function ComplaintNew() {
  const navigate = useNavigate();
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [form, setForm] = useState({
    title: "",
    description: "",
    category: CATEGORIES[0],
    priority: "MITTEL" as (typeof PRIORITIES)[number],
    customerName: "",
    customerEmail: "",
    customerPhone: "",
    orderNumber: "",
    dueDate: "",
  });

  function set<K extends keyof typeof form>(key: K, value: (typeof form)[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!form.title.trim() || !form.description.trim() || !form.customerName.trim()) {
      setError("Bitte Titel, Beschreibung und Kundenname ausfüllen.");
      return;
    }
    setSaving(true);
    try {
      const created = await api.createComplaint({
        ...form,
        dueDate: form.dueDate ? new Date(form.dueDate).toISOString() : null,
      });
      navigate(`/complaints/${created.id}`);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="max-w-2xl space-y-6">
      <header>
        <p className="font-display text-2xl font-semibold text-stone-900">Neue Reklamation erfassen</p>
        <p className="mt-1 text-sm text-stone-500">Eine Referenznummer wird automatisch vergeben.</p>
      </header>

      <form onSubmit={submit} className="space-y-5 rounded-xl border border-stone-200 bg-white p-6">
        <Field label="Titel *">
          <input
            value={form.title}
            onChange={(e) => set("title", e.target.value)}
            className="w-full rounded-md border border-stone-200 px-3 py-2 text-sm outline-none focus:border-stone-400"
            placeholder="Kurze Zusammenfassung des Problems"
          />
        </Field>

        <Field label="Beschreibung *">
          <textarea
            value={form.description}
            onChange={(e) => set("description", e.target.value)}
            rows={4}
            className="w-full rounded-md border border-stone-200 px-3 py-2 text-sm outline-none focus:border-stone-400"
            placeholder="Details zur Reklamation"
          />
        </Field>

        <div className="grid grid-cols-2 gap-4">
          <Field label="Kategorie">
            <select
              value={form.category}
              onChange={(e) => set("category", e.target.value)}
              className="w-full rounded-md border border-stone-200 px-3 py-2 text-sm"
            >
              {CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Priorität">
            <select
              value={form.priority}
              onChange={(e) => set("priority", e.target.value as any)}
              className="w-full rounded-md border border-stone-200 px-3 py-2 text-sm"
            >
              {PRIORITIES.map((p) => (
                <option key={p} value={p}>
                  {PRIORITY_LABELS[p]}
                </option>
              ))}
            </select>
          </Field>
        </div>

        <div className="border-t border-stone-100 pt-5">
          <p className="mb-3 text-sm font-medium text-stone-700">Kundendaten</p>
          <Field label="Name *">
            <input
              value={form.customerName}
              onChange={(e) => set("customerName", e.target.value)}
              className="w-full rounded-md border border-stone-200 px-3 py-2 text-sm outline-none focus:border-stone-400"
            />
          </Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label="E-Mail">
              <input
                type="email"
                value={form.customerEmail}
                onChange={(e) => set("customerEmail", e.target.value)}
                className="w-full rounded-md border border-stone-200 px-3 py-2 text-sm outline-none focus:border-stone-400"
              />
            </Field>
            <Field label="Telefon">
              <input
                value={form.customerPhone}
                onChange={(e) => set("customerPhone", e.target.value)}
                className="w-full rounded-md border border-stone-200 px-3 py-2 text-sm outline-none focus:border-stone-400"
              />
            </Field>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Bestellnummer">
              <input
                value={form.orderNumber}
                onChange={(e) => set("orderNumber", e.target.value)}
                className="w-full rounded-md border border-stone-200 px-3 py-2 text-sm outline-none focus:border-stone-400"
              />
            </Field>
            <Field label="Fälligkeit">
              <input
                type="date"
                value={form.dueDate}
                onChange={(e) => set("dueDate", e.target.value)}
                className="w-full rounded-md border border-stone-200 px-3 py-2 text-sm outline-none focus:border-stone-400"
              />
            </Field>
          </div>
        </div>

        {error && <p className="text-sm text-red-600">{error}</p>}

        <div className="flex justify-end gap-3 pt-2">
          <button
            type="button"
            onClick={() => navigate(-1)}
            className="rounded-md border border-stone-200 px-4 py-2 text-sm font-medium text-stone-600"
          >
            Abbrechen
          </button>
          <button
            type="submit"
            disabled={saving}
            className="rounded-md px-5 py-2 text-sm font-medium text-white disabled:opacity-50"
            style={{ backgroundColor: "var(--color-teal)" }}
          >
            {saving ? "Speichert…" : "Reklamation erfassen"}
          </button>
        </div>
      </form>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="mb-4">
      <label className="mb-1 block text-xs font-medium text-stone-500">{label}</label>
      {children}
    </div>
  );
}
