export const STATUSES = [
  "NEU",
  "IN_BEARBEITUNG",
  "WARTET_AUF_KUNDE",
  "ESKALIERT",
  "GELOEST",
  "GESCHLOSSEN",
] as const;

export type Status = (typeof STATUSES)[number];

export const PRIORITIES = ["NIEDRIG", "MITTEL", "HOCH", "KRITISCH"] as const;
export type Priority = (typeof PRIORITIES)[number];

export const STATUS_LABELS: Record<Status, string> = {
  NEU: "Neu",
  IN_BEARBEITUNG: "In Bearbeitung",
  WARTET_AUF_KUNDE: "Wartet auf Kunde",
  ESKALIERT: "Eskaliert",
  GELOEST: "Gelöst",
  GESCHLOSSEN: "Geschlossen",
};

export const PRIORITY_LABELS: Record<Priority, string> = {
  NIEDRIG: "Niedrig",
  MITTEL: "Mittel",
  HOCH: "Hoch",
  KRITISCH: "Kritisch",
};

export interface Complaint {
  id: string;
  referenceNo: string;
  title: string;
  description: string;
  category: string;
  status: Status;
  priority: Priority;
  customerName: string;
  customerEmail: string | null;
  customerPhone: string | null;
  orderNumber: string | null;
  assignedToId: string | null;
  assignedToName?: string | null;
  resolution: string | null;
  dueDate: string | null;
  resolvedAt: string | null;
  createdAt: string;
  updatedAt: string;
  comments?: Comment[];
}

export interface Comment {
  id: string;
  content: string;
  createdAt: string;
  complaintId: string;
  authorId: string | null;
  authorName?: string | null;
}

export interface User {
  id: string;
  name: string;
  email: string;
}

export interface Paginated<T> {
  data: T[];
  pagination: {
    page: number;
    pageSize: number;
    total: number;
    totalPages: number;
  };
}

export interface Stats {
  total: number;
  open: number;
  overdue: number;
  avgResolutionDays: number | null;
  byStatus: { status: Status; count: number }[];
  byPriority: { priority: Priority; count: number }[];
  byCategory: { category: string; count: number }[];
  last30Days: { day: string; count: number }[];
}
