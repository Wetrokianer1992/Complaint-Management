import type { Complaint, Paginated, Stats, User, Comment } from "./types";

const BASE = "/api";

async function request<T>(path: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || `Anfrage fehlgeschlagen (${res.status})`);
  }
  if (res.status === 204) return undefined as T;
  return res.json();
}

export interface ComplaintFilters {
  status?: string;
  priority?: string;
  category?: string;
  assignedToId?: string;
  search?: string;
  sort?: string;
  page?: number;
  pageSize?: number;
}

export const api = {
  listComplaints(filters: ComplaintFilters = {}) {
    const params = new URLSearchParams();
    Object.entries(filters).forEach(([k, v]) => {
      if (v !== undefined && v !== "") params.set(k, String(v));
    });
    return request<Paginated<Complaint>>(`/complaints?${params.toString()}`);
  },
  getComplaint(id: string) {
    return request<Complaint>(`/complaints/${id}`);
  },
  createComplaint(data: Partial<Complaint>) {
    return request<Complaint>(`/complaints`, {
      method: "POST",
      body: JSON.stringify(data),
    });
  },
  updateComplaint(id: string, data: Partial<Complaint>) {
    return request<Complaint>(`/complaints/${id}`, {
      method: "PATCH",
      body: JSON.stringify(data),
    });
  },
  deleteComplaint(id: string) {
    return request<void>(`/complaints/${id}`, { method: "DELETE" });
  },
  addComment(complaintId: string, content: string, authorId?: string | null) {
    return request<Comment>(`/complaints/${complaintId}/comments`, {
      method: "POST",
      body: JSON.stringify({ content, authorId }),
    });
  },
  getStats() {
    return request<Stats>(`/complaints/stats`);
  },
  listUsers() {
    return request<User[]>(`/users`);
  },
};
